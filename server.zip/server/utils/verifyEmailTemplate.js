export default function verificationEmail(name, code) {
  return `
    <div>
      <h2>Hello ${name},</h2>
      <p>Your OTP code is: <strong>${code}</strong></p>
      <p>This code will expire in 10 minutes.</p>
    </div>
  `;
}
